<template>
  <div style="padding: 20px;">
    <el-card>
      <h2>🤖 AI 辅助诊断工作台</h2>
      <p>这里将集成 KAN+UNet 模型推理功能...</p>
    </el-card>
  </div>
</template>
