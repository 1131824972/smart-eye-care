<template>
  <div style="padding: 20px;">
    <el-card>
      <h2>📂 历史病历档案</h2>
      <p>这里将展示历史诊断记录和图谱分析...</p>
    </el-card>
  </div>
</template>
