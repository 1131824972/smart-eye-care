<template>
  <div style="padding: 20px;">
    <el-card>
      <h2>🏥 患者信息管理</h2>
      <p>这里将展示患者列表和录入表单...</p>
    </el-card>
  </div>
</template>
