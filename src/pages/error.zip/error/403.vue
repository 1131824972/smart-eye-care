<script lang="ts" setup>
import Layout from "./components/Layout.vue"
import Svg403 from "./images/403.svg?component" // vite-svg-loader 插件的功能
</script>

<template>
  <Layout>
    <Svg403 />
  </Layout>
</template>
