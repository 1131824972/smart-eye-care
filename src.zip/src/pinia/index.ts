export const pinia = createPinia()
